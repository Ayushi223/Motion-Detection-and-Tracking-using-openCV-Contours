
## How to Run 
1. Install **Flask**:

    ```
    pip install flask
    ```

2. Run the app:

    ```
    python server.py
    
    copy server address'
    run on browser
    http://0.0.0.0:5000 most probably
    
    
    if ND ONLY IF does not run //
    remove _, b4 cnts
    
    recorder functionality not working idkwhy
    
