import cv2, time, pandas
import numpy as np
from datetime import datetime
import threading
first_frame=None



class VideoCamera(object):

    def __init__(self):
        # Open a camera
        self.cap = cv2.VideoCapture(0)

        # Initialize video recording environment
        self.is_record = False
        self.out = None


    def __del__(self):
        self.cap.release()

    def get_frame(self):
        global first_frame
        while True:
            ret, frame = self.cap.read()
            ret, first_frame = self.cap.read()

            

            imgContour=frame.copy()
            imgBlur = cv2.GaussianBlur(frame,(7,7),1)
            imgGray = cv2.cvtColor(imgBlur,cv2.COLOR_BGR2GRAY)

            
            imgCanny=cv2.Canny(imgGray,86,89)
            kernel=np.ones((5,5))
            imgDil=cv2.dilate(imgCanny,kernel,iterations= 1)

            _, contours,hierarchy=cv2.findContours(imgDil,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)

            for cnt in contours:
                area=cv2.contourArea(cnt)
                areaMin=5000
                if area>areaMin:
                    cv2.drawContours(imgContour,cnt,-1,(255,0,255),7)
                    par1=cv2.arcLength(cnt,True)
                    approx=cv2.approxPolyDP(cnt,0.02*par1,True)
                    x,y,w,h=cv2.boundingRect(approx)
                    cv2.rectangle(imgContour,(x,y),(x+w,y+h),(0,255,0),5)
                    cv2.putText(imgContour,"Points"+str(len(approx)),(x+w+20,y+20),cv2.FONT_HERSHEY_COMPLEX,.7,(0,255,0),2)
                    cv2.putText(imgContour,"Area:"+str(int(area)),(x+w+20,y+45),cv2.FONT_HERSHEY_COMPLEX,0.7,(0,255,0),2)
                    frame=imgContour

            if ret:
                ret, jpeg = cv2.imencode('.jpg', frame)

                # Record video
                if self.is_record:
                    if self.out == None:
                        fourcc = cv2.VideoWriter_fourcc(*'MJPG')
                        self.out = cv2.VideoWriter('./static/video.avi',fourcc, 20.0, (640,480))


                    if ret:
                        self.out.write(frame)
                    else:
                        if self.out != None:
                            self.out.release()
                            self.out = None

                return jpeg.tobytes()

            else:
                return None

    def start_record(self):
        self.is_record = True


    def stop_record(self):
        self.is_record = False



