import cv2, time, pandas
from datetime import datetime
import threading
first_frame=None



class VideoCamera(object):
    
    def __init__(self):
        # Open a camera
        self.cap = cv2.VideoCapture(0)
      
        # Initialize video recording environment
        self.is_record = False
        self.out = None

    
    def __del__(self):
        self.cap.release()
    
    def get_frame(self):
        global first_frame
        while True:
            ret, frame = self.cap.read()
            ret, first_frame = self.cap.read()
        
            delta_frame = cv2.absdiff(first_frame,frame)
            gray = cv2.cvtColor(delta_frame, cv2.COLOR_BGR2GRAY)
            delta_frame = cv2.GaussianBlur(gray,(5,5),0)
    
            if  first_frame is None :
                first_frame = gray
                continue
    
            thresh_delta = cv2.threshold(delta_frame,20,255,cv2.THRESH_BINARY)[1]
            thresh_delta = cv2.dilate(thresh_delta, None, iterations=3)
    
            (_, cnts,_) = cv2.findContours(thresh_delta.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
            for contour in cnts:
                if cv2.contourArea(contour) < 700:
                    continue
                (x, y, w, h) = cv2.boundingRect(contour)
                cv2.rectangle(frame, (x,y), (x+w,y+h), (0, 255, 0), 2)
                cv2.putText(frame,"Status:{}".format('Movement'),(10,20),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),3)

            if ret:
                ret, jpeg = cv2.imencode('.jpg', frame)

            # Record video
                if self.is_record:
                    if self.out == None:
                        fourcc = cv2.VideoWriter_fourcc(*'MJPG')
                        self.out = cv2.VideoWriter('./static/video.avi',fourcc, 20.0, (640,480))
                
                    
                    if ret:
                        self.out.write(frame)
                    else:
                        if self.out != None:
                            self.out.release()
                            self.out = None  

                return jpeg.tobytes()
      
            else:
                return None

    def start_record(self):
        self.is_record = True


    def stop_record(self):
        self.is_record = False


            
